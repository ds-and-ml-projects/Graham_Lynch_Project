import sqlite3



def create_table():
    conn = sqlite3.connect('stocks.db') # creating a table for the key statistics
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS Stock_STAT
            (STOCK TEXT PRIMARY KEY,
             Share REAL,
             PE REAL,
             BV REAL,
             DebtAsset REAL,
             DebtEquity REAL,
             EPSGrowth REAL,
             CurrentRatio REAL,
             PEGRatio REAL,
             MarketCap TEXT,
             GrahamScore REAL,
             LynchScore REAL)''')
    conn.commit()
