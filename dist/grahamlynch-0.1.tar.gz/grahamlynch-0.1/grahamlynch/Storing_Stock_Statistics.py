import sqlite3
import csv
import urllib2
import quandl
import warnings
import yahoo_finance
import operator
import math
from yahoo_finance import Share

conn = sqlite3.connect('stocks.db') # creating a table for the key statistics
c = conn.cursor()



# A class with all thGrahamLynch_Projecte motifications done to the stocks
class StockInformation:

    def __init__(self, key_statistic, amnt_stocks):
        self.key_statistic = key_statistic
        self.amnt_stocks = 5
        with open('companylist.csv', 'rb') as csvfile:
            key_statistic = []
            spamreader = csv.reader(csvfile, quotechar = '|')

            # created a list where we get all the stock that has a value for the market cap and store the ticker in the tickers list
            for row in spamreader:
                if row[3] != "n/a":
                    key_statistic.append([row[0]])

            # if you would like for this program to run quicker, maybe choose a smaller amount of stocks to evaulate
            amnt_stocks = len(key_statistic)
            Evaulate_Stocks = StockInformation(key_statistic, amnt_stocks)
            Evaulate_Stocks.Market_Share()


        # tuples shall be used to navigate the errors when extracting information on stocks
        self.ERRORS_YAHOO = (TypeError, urllib2.HTTPError, yahoo_finance.YQLResponseMalformedError)
        self.ERRORS_QUANDL = (quandl.errors.quandl_error.NotFoundError, TypeError, quandl.errors.quandl_error.QuandlError)

    def Market_Share(self):
        for i in range(self.amnt_stocks):
            try:
                indivdiual_stock = Share(self.key_statistic[i][0])
                stock_marketshare = float(indivdiual_stock.get_price())
                if isinstance(stock_marketshare, float) == True:
                    DB_Store = StockDATAbase(self.key_statistic[i][0], stock_marketshare, "Share") # storing into the database indivdiually
                    DB_Store.CREATE_TABLE()
                    DB_Store.IFEXIST()

            except self.ERRORS_YAHOO as e:
                pass
        self.PE_Ratio()

    def PE_Ratio(self):
        for i in range(self.amnt_stocks):
            try:
                indivdiual_stock = Share(self.key_statistic[i][0])
                stock_PE = float(indivdiual_stock.get_price_earnings_ratio())
                if isinstance(stock_PE, float) == True:
                    DB_Store = StockDATAbase(self.key_statistic[i][0], stock_PE, "PE") # storing into the database indivdiually
                    DB_Store.IFEXIST()

            except self.ERRORS_YAHOO as e:
                pass
        #self.BV_Ratio()

    def BV_Ratio(self):
        for i in range(self.amnt_stocks):
            try:
                indivdiual_stock = Share(self.key_statistic[i][0])
                stock_BV = float(indivdiual_stock.get_price_book())
                if isinstance(stock_BV, float) == True:
                    DB_Store = StockDATAbase(self.key_statistic[i][0], stock_BV, "BV") # storing into the database indivdiually
                    DB_Store.IFEXIST()

            except self.ERRORS_YAHOO as e:
                pass
        self.DebtAsset_Ratio()

    def DebtAsset_Ratio(self):
        for i in range (self.amnt_stocks):
            try:
                current_asset = quandl.get("SF0/"+str(self.key_statistic[i][0])+"_ASSETSC_MRY", authtoken="ivu6KgaViZxoyqic7QkE")
                total_debt = quandl.get("SF0/"+str(self.key_statistic[i][0])+"_DEBT_MRY", authtoken="ivu6KgaViZxoyqic7QkE")

                with warnings.catch_warnings():
                    warnings.simplefilter("ignore", category=RuntimeWarning)
                    CA = current_asset.values.mean() # the average of the current assets (approx. 5 years)
                    TD = total_debt.values.mean() # the avg of the total debt (approx. 5 years)

                    # for when values in QUANDL are n/a, they will output True when computing their mean...
                    if ((CA != True) or (TD != True)):
                        stock_DARatio = TD/CA # the ratio of Total Debt to Current Asset Ratio. Hence, DA...

                        DB_Store = StockDATAbase(self.key_statistic[i][0], stock_DARatio, "DebtAsset") # storing into the database indivdiually
                        DB_Store.IFEXIST()

            except self.ERRORS_QUANDL as e:
                pass
        self.DebtEquity_Ratio()

    def DebtEquity_Ratio(self):
        for i in range (self.amnt_stocks):
            try:
                total_equity = quandl.get("SF0/"+str(self.key_statistic[i][0])+"_EQUITY_MRY", authtoken="ivu6KgaViZxoyqic7QkE")
                total_debt = quandl.get("SF0/"+str(self.key_statistic[i][0])+"_DEBT_MRY", authtoken="ivu6KgaViZxoyqic7QkE")

                with warnings.catch_warnings():
                    warnings.simplefilter("ignore", category=RuntimeWarning)
                    TE = total_equity.values.mean() # the average of the current assets (approx. 5 years)
                    TD = total_debt.values.mean() # the avg of the total debt (approx. 5 years)

                    # for when values in QUANDL are n/a, they will output True when computing their mean...
                    if ((TE != True) or (TD != True)):
                        stock_DARatio = TD/TE # the ratio of Total Debt to Current Asset Ratio. Hence, DA...

                        DB_Store = StockDATAbase(self.key_statistic[i][0], stock_DARatio, "DebtEquity") # storing into the database indivdiually
                        DB_Store.IFEXIST()

            except self.ERRORS_QUANDL as e:
                pass
        self.EPS_GrowthRatio()

    def EPS_GrowthRatio(self):
        for i in range (self.amnt_stocks):
            try:
                EPS = quandl.get("SF0/"+str(self.key_statistic[i][0])+"_EPS_MRY", authtoken="ivu6KgaViZxoyqic7QkE")

                with warnings.catch_warnings():
                    warnings.simplefilter("ignore", category=RuntimeWarning)

                    for j in range((len(EPS.values)-1), -1, -1):
                        if (EPS.values[j] > 0):
                            current_year = EPS.values[j]
                            break

                    for k in range(len(EPS.values)):
                        if (EPS.values[k] > 0):
                            last_avail_yr = EPS.values[k]
                            break

                    for num in ( num for num,x in enumerate(EPS.values) if x == current_year):
                        pos_current_yr = num
                    for num in ( num for num,x in enumerate(EPS.values) if x == last_avail_yr):
                        pos_last_yr = num
                    ttl_yrs = (pos_current_yr - pos_last_yr) + 1
                    eps_growth_diff = current_year/last_avail_yr
                    yrs_exponent = (1/float(ttl_yrs))
                    eps_growth_growth = round(((eps_growth_diff ** yrs_exponent)-1)*100, 2)

                    if eps_growth_growth != 0:
                        DB_Store = StockDATAbase(self.key_statistic[i][0], eps_growth_growth, "EPSGrowth") # storing into the database indivdiually
                        DB_Store.IFEXIST()

            except self.ERRORS_QUANDL as e:
                pass
        self.Current_Ratio()

    def Current_Ratio(self):
        for i in range (self.amnt_stocks):
            try:
                crrnt_rtio = quandl.get("SF0/"+str(self.key_statistic[i][0])+"_CURRENTRATIO_MRY", authtoken="ivu6KgaViZxoyqic7QkE")
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore", category=RuntimeWarning)
                    stock_CR = crrnt_rtio.values.mean()
                    if (stock_CR != True):
                        DB_Store = StockDATAbase(self.key_statistic[i][0], stock_CR, "CurrentRatio") # storing into the database indivdiually
                        DB_Store.IFEXIST()

            except self.ERRORS_QUANDL as e:
                pass
        self.PEG_Ratio()

    def PEG_Ratio(self):
        for i in range(self.amnt_stocks):
            try:
                indivdiual_stock = Share(self.key_statistic[i][0])
                stock_PEGrowth = float(indivdiual_stock.get_price_earnings_growth_ratio())

                if isinstance(stock_PEGrowth, float) == True:
                    DB_Store = StockDATAbase(self.key_statistic[i][0], stock_PEGrowth, "PEGRatio") # storing into the database indivdiually
                    DB_Store.IFEXIST()
            except self.ERRORS_YAHOO as e:
                pass
        self.Market_CAP()

    def Market_CAP(self):
        for i in range(self.amnt_stocks):
            try:
                tresholds = [2000000000, 10000000000] # Mid_cap, Large_cap
                indivdiual_stock = Share(self.key_statistic[i][0])
                multiplier = indivdiual_stock.get_market_cap()[-1]
                stock_MktCap = float(indivdiual_stock.get_market_cap()[:-1])

                if isinstance(stock_MktCap, float) == True:
                    value = self.conversion(multiplier, stock_MktCap)
                    if value > tresholds[1]:
                        DB_Store = StockDATAbase(self.key_statistic[i][0], "Large-Market Cap", "MarketCap") # storing into the database indivdiually
                        DB_Store.IFEXIST()
                    elif value > tresholds[0]:
                        DB_Store = StockDATAbase(self.key_statistic[i][0], "Mid-Market Cap", "MarketCap") # storing into the database indivdiually
                        DB_Store.IFEXIST()
                    else:
                        DB_Store = StockDATAbase(self.key_statistic[i][0], "Small-Market Cap", "MarketCap") # storing into the database indivdiually
                        DB_Store.IFEXIST()
            except self.ERRORS_YAHOO as e:
                pass
        StockMethod()
        StockDATAbase.CLOSE()

    def conversion(self, mult, mkt_cap):
        if mult == 'M':
            return int(mkt_cap * 1000000)
        elif mult == 'B':
            return int(mkt_cap * 1000000000)
